import {cp,mkdir,readdir,readFile,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
const arg=process.argv.find(v=>v.startsWith('--base='));
let base=arg?arg.slice(7):'/';base='/'+base.replace(/^\/+|\/+$/g,'');if(base!=='/')base+='/';
await rm('dist',{recursive:true,force:true});await mkdir('dist',{recursive:true});await cp('public','dist',{recursive:true});
async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())await walk(p);else if(/\.(html|js|css)$/.test(p)){let s=await readFile(p,'utf8');if(base!=='/')s=s.replace(/(["'`])\/(?!\/)/g,(_,q)=>q+base);await writeFile(p,s);}}}
await walk('dist');console.log('Built dist/ with base '+base);
