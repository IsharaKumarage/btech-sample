# BeauTech website — full source

Complete editable frontend source from the website created in this conversation. This is the multi-file project, not the single-file HTML export.

## Pages

- `/` — client marketplace, all service categories, booking preview, client-logo placeholders, review carousel and client FAQ.
- `/for-business/` — Beauty Business Suite, BeauTech Bridal (Bridal / Rental / Tailoring), Dental, HR & Payroll, client stories and business FAQ.
- `/sign-in/` and `/sign-up/` — separate client/business account screens.

## Run locally

Requires Node.js. No third-party dependencies or npm installation step is needed.

```sh
npm run dev
```

Open `http://localhost:3000`. Set the `PORT` environment variable to change the port. Use this server rather than double-clicking the multi-file HTML, because source URLs are root-relative.

## Static build

```sh
npm run build
```

Deploy the generated `dist/` folder using a host that serves directory index.html files.

For hosting at a repository subpath rather than a domain root:

```sh
npm run build -- --base=/YOUR-REPOSITORY-NAME/
```

## Upload to GitHub

1. Extract this ZIP.
2. Upload/commit the contents of `BeauTech_Website_Source` as the repository contents.
3. Include `public/`, `scripts/`, `package.json`, `.gitignore` and this README; keep the directory structure.
4. Uploading the ZIP alone does not unpack it into the repository.

No original hosting identity, Git credentials, secrets or .git history are included.

## Edit

- `public/index.html`: client landing page.
- `public/for-business/index.html`: business landing page.
- `public/style.css`: shared responsive styling and brand colours.
- `public/app.js`: booking filters, product dialogs, onboarding previews and reviews controls.
- `public/auth.js`: authentication preview screens.
- `public/sign-in/index.html`, `public/sign-up/index.html`: account page shells.
- `public/assets/`: photographs.

## Implementation status

Frontend design prototype only. Google/email authentication, real accounts, persistent data, live availability, booking confirmation, payments and 14-day trial activation are NOT connected. No backend or auth credentials are included. All sign-in and booking interactions are labelled previews.

Business listings and appointment times are examples. Client logos, quotes and ratings are placeholders pending approved content. Specialist category support must be confirmed with the BeauTech team.

Manrope is the current available font fallback. Locally installed Roobert is preferred when present; licensed Roobert/Tartuffo webfonts are not bundled. Google Fonts needs internet; system fonts work offline.

Photography is reference imagery via Unsplash. Replace with approved brand photography before launch. No Fresha trademark or commercial font licence is supplied.
